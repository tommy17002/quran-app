function RightSection()
{
    return <div className="bg-slate-200 basis-3/4"></div>
}

export default RightSection
function Setting()
{
    return <>Setting</>;
}

export default Setting;